  <link rel="stylesheet" href="./style.css" type="text/css" media="screen" title="no title" charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <script type="text/javascript" src="./js/getpage.js"></script>

  <script type="text/javascript" src="./js/shuffle.js"></script>
  <script type="text/javascript" src="./js/list.js"></script>
 
  <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900' rel='stylesheet' type='text/css'>
  <style>@import url(http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900);</style>
   <!--fb-->
  <link rel="stylesheet" type="text/css" href="./fancybox/jquery.fancybox-1.3.4.css" media="screen" />
  <script type="text/javascript" src="./jquery/jquery.min.js"></script>
  <script>!window.jQuery && document.write('<script src="jquery-1.4.3.min.js"><\/script>');</script>
    <script type="text/javascript" src="./fancybox/jquery.fancybox-1.3.4.js"></script> 
  <script type="text/javascript" src="./fancybox/jquery.mousewheel-3.0.4.pack.js"></script> 
  <script type="text/javascript" src="./js/fancybox_style.js"></script>
<!--fb-->


