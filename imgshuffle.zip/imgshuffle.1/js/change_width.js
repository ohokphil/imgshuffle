// JavaScript Document
if (document.getElementById('container').style.width < '1000px';
	{document.getElementById('title').style.width = '780px'
		}
else
	{document.getElementById('title').style.width = '1050px'
		}