//Create the Portfolio Array. A container for the Modules.
var portfolio = [];

//Build the Array of Module Objects & Their Properties
    portfolio[0] = new portMod(0, 'd41c17', 'fancybox', 'th_sample1\.jpg', '.\/images\/sample1\.jpg', 'Sample Image 1', 'Category');
    portfolio[1] = new portMod(1, '632c3f', 'fancybox', 'th_sample2\.jpg', '.\/images\/sample2\.jpg', 'Sample Image 2', 'Category');
    portfolio[2] = new portMod(2, '64cf35', 'fancybox', 'th_sample3\.jpg', '.\/images\/sample3\.jpg', 'Sample Image 3', 'Category');
    portfolio[3] = new portMod(3, 'ccdd32', 'fancybox', 'th_sample4\.jpg', '.\/images\/sample4\.jpg', 'Sample Image 4', 'Category'); 
    portfolio[4] = new portMod(4, 'd41c17', 'fancybox', 'th_sample5\.jpg', '.\/images\/sample5\.jpg', 'Sample Image 5', 'Category');
    portfolio[5] = new portMod(5, '632c3f', 'fancybox', 'th_sample6\.jpg', '.\/images\/sample6\.jpg', 'Sample Image 6', 'Category');
    portfolio[6] = new portMod(6, '64cf35', 'fancybox', 'th_sample7\.jpg', '.\/images\/sample7\.jpg', 'Sample Image 7', 'Category');
    portfolio[7] = new portMod(7, 'ccdd32', 'fancybox', 'th_sample8\.jpg', '.\/images\/sample8\.jpg', 'Sample Image 8', 'Category');    
    portfolio[8] = new portMod(8, 'd41c17', 'fancybox', 'th_sample9\.jpg', '.\/images\/sample9\.jpg', 'Sample Image 9', 'Category');
    portfolio[9] = new portMod(9, '632c3f', 'fancybox', 'th_sample10\.jpg', '.\/images\/sample10\.jpg', 'Sample Image 10', 'Category');
    portfolio[10] = new portMod(10, '64cf35', 'fancybox', 'th_sample11\.jpg', '.\/images\/sample11\.jpg', 'Sample Image 11', 'Category');
    portfolio[11] = new portMod(11, 'ccdd32', 'fancybox', 'th_sample12\.jpg', '.\/images\/sample12\.jpg', 'Sample Image 12', 'Category');  







