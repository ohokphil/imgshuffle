//The Fisher Yates Shuffle Script
function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex ;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
}

//Constructor for Portfolio Modules
function portMod(id, color, size, thumb, image, info, category) {
this.id = id;
this.color = color;
this.size = size;
this.thumb = thumb; 
this.image = image; 
this.info = info;
this.category = category;
}


function showPort() {
shuffle(portfolio);
console.log(portfolio);
for (x in portfolio) {

  document.write("<div class=\"pic\" style=\"background-color:#" + portfolio[x].color + "\"><a class=\"" + portfolio[x].size + "\" rel=\"gallery\" href=\"" + portfolio[x].image + "\"><div class=\"info\">" + portfolio[x].info + "<\/div><img src=\".\/images\/thumbs\/" + portfolio[x].thumb + "\" title=\"" + portfolio[x].info + "\"\/><\/a><\/div>");

    }
}

function showType() {
shuffle(typography);
console.log(typography);
for (x in typography) {

  document.write("<div class=\"pic\" style=\"background-color:#" + typography[x].color + "\"><a class=\"" + typography[x].size + "\" rel=\"gallery\" href=\"" + typography[x].image + "\"><div class=\"info\">" + typography[x].info + "<\/div><img src=\".\/images\/thumbs\/" + typography[x].thumb + "\" title=\"" + typography[x].info + "\"\/><\/a><\/div>");

    }
}

function showIll() {
shuffle(illustration);
console.log(illustration);
for (x in illustration) {

  document.write("<div class=\"pic\" style=\"background-color:#" + illustration[x].color + "\"><a class=\"" + illustration[x].size + "\" rel=\"gallery\" href=\"" + illustration[x].image + "\"><div class=\"info\">" + illustration[x].info + "<\/div><img src=\".\/images\/thumbs\/" + illustration[x].thumb + "\" title=\"" + illustration[x].info + "\"\/><\/a><\/div>");

    }
}

function showMot() {
shuffle(motion);
console.log(motion);
for (x in motion) {

  document.write("<div class=\"pic\" style=\"background-color:#" + motion[x].color + "\"><a class=\"" + motion[x].size + "\" rel=\"gallery\" href=\"" + motion[x].image + "\"><div class=\"info\">" + motion[x].info + "<\/div><img src=\".\/images\/thumbs\/" + motion[x].thumb + "\" title=\"" + motion[x].info + "\"\/><\/a><\/div>");

    }
}

function showPho() {
shuffle(photography);
console.log(photography);
for (x in photography) {

  document.write("<div class=\"pic\" style=\"background-color:#" + photography[x].color + "\"><a class=\"" + photography[x].size + "\" rel=\"gallery\" href=\"" + photography[x].image + "\"><div class=\"info\">" + photography[x].info + "<\/div><img src=\".\/images\/thumbs\/" + photography[x].thumb + "\" title=\"" + photography[x].info + "\"\/><\/a><\/div>");

    }
}

    var typography = [];
    var illustration = [];
    var motion = [];
    var photography = [];
    var other = []; 

    var currentCat = 0;   



function buildCats() {
    for (x in portfolio) {

        if (portfolio[x].category == 'typography') {   
        typography.push(portfolio[x]);
        }

        else  if (portfolio[x].category == 'illustration') {
            illustration.push(portfolio[x]);
            
        }

        else  if (portfolio[x].category == 'motion') {
            motion.push(portfolio[x]);
            
        }

        else  if (portfolio[x].category == 'photography') {
            photography.push(portfolio[x]);   
        }

        else if (portfolio[x].category != 'typography' || 'illustration' || 'motion' || 'photography')   {
            other.push(portfolio[x]);
        }

        else {
            return portfolio;
            alert ('something was not categorized')
        }
        
    }

}





