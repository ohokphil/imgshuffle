$(document).ready(function() {
	  $("a.gallery_img").fancybox({
	'opacity'		: true,
	'overlayShow'	: true,
	'transitionIn'	: 'none',
	'transitionOut'	: 'none',
	'titlePosition'	: 'inside',
	'padding'		: 1,
	'border'        : 0,
			});
			
	 $("a[rel=gallery]").fancybox({
	  'transitionIn'		: 'none',
	  'transitionOut'		: 'none',
	  'titlePosition' 		: 'over',
	  'titleFormat'		: 'none',
			});
	/*
	*   Flash
	*/

	  $("a.728_90").fancybox({
	  'width'		: '728px',
	  'height'		: '90px',
	  'autoScale'	: false,
	  'opacity'		: true,
	  'overlayShow'	: true,
	  'transitionIn'	: 'none',
	  'transitionOut'	: 'none',
	  'titlePosition'	: 'none',
	  'padding'			: 10,
			});

          $("a.750_500").fancybox({
	  'width'		: '750px',
	  'height'		: '500px',
	  'autoScale'		: false,
	  'opacity'		: true,
	  'overlayShow'		: true,
	  'transitionIn'	: 'none',
	  'transitionOut'	: 'none',
	  'padding'		: 10,
			});

	  $("a.300_600").fancybox({
	  'width'			: '300px',
	  'height'			: '600px',
	  'autoScale'		: false,
	  'opacity'			: true,
	  'overlayShow'		: true,
	  'transitionIn'	: 'none',
	  'transitionOut'	: 'none',
	  'padding'			: 10,
			});	

	  $("a.160_600").fancybox({
	  'width'			: '160px',
	  'height'			: '600px',
	  'autoScale'		: true,
	  'opacity'			: true,
	  'overlayShow'		: true,
	  'transitionIn'	: 'none',
	  'transitionOut'	: 'none',
	  'padding'			: 10,
			});	

	/*
	*   Iframes
	*/

	  $("a.iframe").fancybox({
	  'width'		: '70%',
	  'height'		: '70%',
	  'autoScale'		: false,
	  'transitionIn'	: 'none',
	  'transitionOut'	: 'none',
	  'type'		: 'iframe',
	  'href'		: null,
			});
		});

