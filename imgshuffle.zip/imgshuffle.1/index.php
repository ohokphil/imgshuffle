<!DOCTYPE html>

<html>

<head>
  <title>Image Shuffle by Phillip Yniguez</title>
  <?php include('./scripts.php') ?>
</head>

<body>

<div id="container">


<div id="grid">
<script type="text/javascript">
showPort();
</script>
</div>


 
<div id="pushbottom"></div>
</div><!--container-->



<div id="footer" name="footer"></div>
</body>

</html>
